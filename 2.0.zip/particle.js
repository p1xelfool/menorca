/*
----------------------------------------------------------------

----------------------------------------------------------------
*/


let Particle = function (x, y, tempColumns, tempCor, tempIndex, tempIntervalCells, tempPg, tempW, tempH, layer, iMult, mod, modMult, GlSpeedX, GlSpeedY, hasGlitch) {
    this.loc = createVector(0, y);
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);

    this.columns = tempColumns;

    this.killingTime = 2.0;
    this.lifespan = 80.0;
    this.index = tempIndex;
    this.intervalCells = tempIntervalCells;

    this.finalPg = tempPg;
    this.w = tempW;
    this.h = tempH;

    this.step = (this.h)/this.columns;
    this.size = this.step/2-1;
    this.layer = layer;

    this.rrr = int(red(color(tempCor)));
    this.ggg = int(green(color(tempCor)));
    this.bbb = int(blue(color(tempCor)));

    this.randGlitchX = floor(random(2,4));
    this.randGlitchY = floor(random(1,2));

    this.iMult = iMult;

    ////MODULO

    this.mod = mod;//floor(random(1, 3.99));
    this.modMult = modMult;//floor(random(1.99, 3.99));

    //////GLITCH SPEED
    this.GlSpeedX = GlSpeedX;//random(1, 10);
    this.GlSpeedY = GlSpeedY;//random(0.1, 0.5);

    if(palettePicker.length > 1 && this.index==1){
            this.cor = color(palette[palettePicker][0]);
    } else if(palettePicker.length > 1 && this.index==2){
        this.cor = color(palette[palettePicker][1]);
    }else{
        this.cor = tempCor;
    }

    ///HAS GLITCH
    this.hasGlitch = hasGlitch;
    

}


Particle.prototype.update = function() {
    // this.sx = 0;
    // this.sy = 0;

    // this.acc = createVector(this.sx,this.sy);
    // this.vel.add(this.acc);
    // this.loc.add(this.vel);

    // this.vel.limit(0.2);
    // this.acc.mult(0);
    // this.vel.mult(0.95);

    this.lifespan -= this.killingTime;


}


Particle.prototype.isDead = function () {
    if (this.lifespan <= 0.0) {
        return true;
    } else {
        return false;
    }
}


Particle.prototype.applyForce = function(f) {
    this.acc.add(f);
}


Particle.prototype.display = function() {

    

        for(let xx=marginX; xx<finalImage.width-marginX; xx++){
            //let yy;
            //yy = 1;////int(finalX) + int(i*this.iMult)*int(i/2+sin(radians(t/2 + this.index)*2));              
            let yy = int(this.loc.y);

            let n = noise(xx/40, yy/40);

            //GLITCH AFTER 120 FRAMES
            // if(t==120){
            //     this.randGlitchX = floor(random(1,40));
            //     this.randGlitchY = floor(random(1,40));
            // }

            let index = int((xx + yy * this.w)*4);
            let index2 = int((xx+t*this.GlSpeedX + yy+t*this.GlSpeedY * this.w)*4);
            


            

            //DEFINE ON A TEMP ARRAY
            //if(this.lifespan>0){

                if((xx>marginX-1 && xx<finalImage.width && yy>marginY && yy<finalImage.height-marginY) && this.layer == 1){
            
                    if (xx%(this.modMult)==0) {
                        if (yy%this.mod==0) {
                            tempPixels[index] = 0;
                            tempPixels[index+1] = 0;
                            tempPixels[index+2] = 0;
                            tempPixels[index+3] = 255;
                        } else {
                            if(n<1){

 
                                    tempPixels[index] = this.rrr;
                                    tempPixels[index+1] = this.ggg;
                                    tempPixels[index+2] = this.bbb;
                                    tempPixels[index+3] = 255;


                                    if(n<noiseThresh2 && this.hasGlitch == true){
                                        tempPixels[index2] = this.rrr;
                                        tempPixels[index2+2] = this.ggg;
                                        tempPixels[index2+3] = this.bbb;
                                        tempPixels[index2+3] = 255;
                                    }

                            }


                        }
                    } else {
                        if (yy%this.mod==0) {
                            if(n<1){


                                tempPixels[index] = this.rrr;
                                tempPixels[index+1] = this.ggg;
                                tempPixels[index+2] = this.bbb;
                                tempPixels[index+3] = 255;
                                
                                if(n<noiseThresh2 && this.hasGlitch == true){
                                    tempPixels[index2] = this.rrr;
                                    tempPixels[index2+2] = this.ggg;
                                    tempPixels[index2+3] = this.bbb;
                                    tempPixels[index2+3] = 255;
                                }
                            }
                        } else {
                            tempPixels[index] = 0;
                            tempPixels[index+1] = 0;
                            tempPixels[index+2] = 0;
                            tempPixels[index+3] = 255;
                        }
                    }


                        // tempPixels[index] = this.rrr;
                        // tempPixels[index+1] = this.ggg;
                        // tempPixels[index+2] = this.bbb;
                        // tempPixels[index+3] = 255;
                    

                }

                else if((xx>marginX-1 && xx<finalImage.width-marginX && yy>marginY && yy<finalImage.height-marginY) && this.layer == 2){



                    //if(this.rrr > 0 && this.ggg>0 && this.bbb>0){
                        tempPixels[index2] = this.rrr;
                        tempPixels[index2+1] = this.ggg;
                        tempPixels[index2+2] = this.bbb;
                        tempPixels[index2+3] = 255;
                    //}   

                }
            //}


        }

    }
