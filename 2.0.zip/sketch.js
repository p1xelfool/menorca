/*
----------------------------------------------------------------

----------------------------------------------------------------
*/

let t = 0.0;
let pg;
let recording = true;
let pgW, pgH;

//SYSTEM
let runners = null;
let numOfP = 100.0;

//MOVEMENT
let c = 0.0;

//CREATIVE MODE
let creativeMode = false;
let border = true;

//PALETTE
let fullCreativeColor = true;
let creativeColor = false;
let finalCol;
let bg;
let palette = [


    ['#d7fe52'],
    ['#0000ff'],
    ['#ff0000'],
    ['#00adcb'],
    ['#6800f6'],
    ['#1dec57'],
    ['#e2e6ec'],
    ['#1dec57', '#e2e6ec'],
    ['#555555'],
    ['#CCFD7A', '#e2e6ec', '#EB79F1'],
    ['#e2e6ec', '#00d8ff'],
    ['#e2e6ec', '#ff5217'],
    ['#c6c7d5', '#cbff00'],
    ['#FF0000', '#00FF00', '#0000FF'],
    ['#FF0000', '#ff5a00', '#f600ff'],
    ['#e2e6ec', '#00FF00'],
    ['#e2e6ec', '#ffde00'],
    ['#e2e6ec', '#0000f4'],
    ['#9ED8DB', '#e2e6ec'],
    ['#CCFD7A', '#6800f6'],
    ['#7689ff', '#5dffa0'],


];


let palette1, palette2;
let palettePicker;

let seed;
let colorPicker;
let numSystems, numSystems2;
let columnsRandom;
let minColumns, maxColumns;

let finalImage, tempPixels;

/////RESOLUTION
let r1, r2;
r1 = 20;
let canvas;

/////SEEDS

let seeds;

//////MARGINS
let marginX;
let marginY;

let seedCount = 0;
let seedIndex = 0;


////PAUSE PLAY
let running = true;

////MODULO
let mod, modMult;
let modMultArray = [2, 3, 4];
let modArray = [2,3,4,6, 8];

let margArray = [0, 2,4,6,8,16];

////PARTICLE NOISE MASK THRESHOLD
let noiseThresh, noiseThresh2;




///CAPTURE
// Create a capturer that exports PNG images in a TAR file
// var fps = 30;
// var capturer = new CCapture({
//     format: 'png',
//     verbose: true,
//     framerate: fps
// });





////SOUND
// let t1 = 0.0; // attack time in seconds
// let l1 = 0.7; // attack level 0.0 to 1.0
// let t2 = 0.3; // decay time in seconds
// let l2 = 0.1; // decay level  0.0 to 1.0

// let env;
// let triOsc;



function setup() {
    canvas = createCanvas(windowWidth, windowHeight);
    frameRate(30);

    seeds = [
        [int($fx.rand()*20000), int($fx.rand()*20000), int($fx.rand()*20000), int($fx.rand()*20000), int($fx.rand()*20000), int($fx.rand()*20000), int($fx.rand()*20000), int($fx.rand()*20000), int($fx.rand()*20000), int($fx.rand()*20000)], 
    ]

    console.log(seeds);

    ////PALETTE
    palettePicker = floor(map($fx.rand(), 0, 1, 0, palette.length));

        ///////MARGINS
    // if (random(10) < 1) {
        border = true;
        marginX = margArray[floor(map($fx.rand(), 0, 1, 0, margArray.length))];//floor(random(3, 20));
        marginY = marginX;//floor(random(0, 10));
    // } else {
        // border = false;
        // marginX = 0;
        // marginY = 0;
   // }

   mod = floor(map($fx.rand(), 0, 1, 2, 4));
   modMult = floor(map($fx.rand(), 0, 1, 1, 3)*2);

   //NOISE THRESH
   noiseThresh = map($fx.rand(), 0, 1, 0.8, 1);
   noiseThresh2 = map($fx.rand(), 0, 1, 0.4, 0.9);

    start(seeds[0][0]);


    ///////SOUND
    // env = new p5.Envelope(t1, l1, t2, l2);
    // triOsc = new p5.Oscillator('triangle');
}

function draw() {
    //     //CAPTURE
    //    if (t === 1) {
    //        capturer.start();
    //    }
    //    if(t == 240){
    //        capturer.stop();
    //        capturer.save();
    //    }


    ////IF NOT PAUSED
    if (running == true) {

        // /////ROTATE THE SEED
        if (t > 1 && t % 300 == 0) {
            ///ADDS TO SEED COUNT
            if (seedCount < 9) {
                seedCount++;
            } else {
                seedCount = 0;
            }

            start(seeds[seedIndex][int(seedCount)]);
        }




        /////SOUND
        // if(frameCount%120 == 0){
        //     let p = random(1);
        //     if(p>0.5){
        //         playSound();
        //     }
        // }


        background(0);
        pgShow();

        ///SECOND IMAGE
        finalImage.loadPixels();

        //////NON-UPSCALE
        for (let x = 0; x < finalImage.width; x++) {
            for (let y = 0; y < finalImage.height; y++) {
                let tempIndex = (x + y * finalImage.width) * 4;

                /////FLASHING END
                // if (t > 236) {
                //     if (t % 2 == 0) {
                //         finalImage.pixels[tempIndex] = tempPixels[tempIndex];
                //         finalImage.pixels[tempIndex + 1] = tempPixels[tempIndex + 1];
                //         finalImage.pixels[tempIndex + 2] = tempPixels[tempIndex + 2];
                //         finalImage.pixels[tempIndex + 3] = tempPixels[tempIndex + 3];
                //     } else {
                //         finalImage.pixels[tempIndex] = 0;
                //         finalImage.pixels[tempIndex + 1] = 0;
                //         finalImage.pixels[tempIndex + 2] = 0;
                //         finalImage.pixels[tempIndex + 3] = 255;
                //     }
                // } else {
                    finalImage.pixels[tempIndex] = tempPixels[tempIndex];
                    finalImage.pixels[tempIndex + 1] = tempPixels[tempIndex + 1];
                    finalImage.pixels[tempIndex + 2] = tempPixels[tempIndex + 2];
                    finalImage.pixels[tempIndex + 3] = tempPixels[tempIndex + 3];
                //}


            }
        }




        // //////////BOTTOM
        // for (let x = 0; x < finalImage.width; x++) {
        //     for (let y = 0; y < finalImage.height; y++) {
        //         let index = (x + y * finalImage.width) * 4;
        //         let index2 = (x+1 + y * finalImage.width) * 4;

        //         if (x%(mod * modMult)==0) {
        //             if (y%mod==0) {

        //             }else{
        //                 tempPixels[index] = 0;
        //                 tempPixels[index+1] = 0;
        //                 tempPixels[index+2] = 0;
        //                 tempPixels[index+3] = 255;
        //                 tempPixels[index2] = 0;
        //                 tempPixels[index2+1] = 0;
        //                 tempPixels[index2+2] = 0;
        //                 tempPixels[index2+3] = 255;
        //             }
        //         }else{
        //             if (y%mod==0) {

        //             }else{
        //                 tempPixels[index] = 0;
        //                 tempPixels[index+1] = 0;
        //                 tempPixels[index+2] = 0;
        //                 tempPixels[index+3] = 255;
        //                 tempPixels[index2] = 0;
        //                 tempPixels[index2+1] = 0;
        //                 tempPixels[index2+2] = 0;
        //                 tempPixels[index2+3] = 255;
        //             }
        //         }

        //     }
        // }

        // let c = color('#000000');

        // for(let i=0; i<20; i++){
        //     pxRect(pg.width/2, pg.height/2, 30+i*4, 10+i*4, c);
        // }
        



        finalImage.updatePixels();

        imageMode(CENTER);
        image(finalImage, windowWidth / 2, windowHeight / 2, windowWidth, windowHeight);

        //console.log(frameRate());

    } /////IF RUNNING

    /////CAPTURE
    //capturer.capture(document.getElementById('defaultCanvas0'));
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
    start(seeds[seedIndex][0]);
}



function pgShow() {
    t++;


    //SYSTEMS
    if (t == 1) {
        for (let i = 0; i < numSystems; i++) {
            runners.push(new ParticleSystem(floor(map($fx.rand(), 0, 1, minColumns, maxColumns)), map($fx.rand(), 0, 1, 1, 2), palette1[i], i, pg, pg.width, pg.height, 1));
        }
    }

    // if (t == 1) {
    //     for (let i = 0; i < numSystems2; i++) {
    //         runners.push(new ParticleSystem(floor(random(minColumns, maxColumns)), random(1,2), palette2[i], i, pg, pg.width, pg.height, 2));
    //     }
    // }


    //RUN SYSTEMS
    for (let i = 0; i < runners.length; i++) {
        let p = runners[i];
        p.force();
        p.nu();
        p.update();
    }






}


function start(finalSeed) {
    $fx.rand.reset();
    if(windowWidth > windowHeight){
        r1=20;
    }else{
        r1=40;
    }

    t = 0.0;
    frameCount = 0;

    noCursor();
    noiseSeed(4);
    strokeWeight(1.01);
    //SEED
    seed = floor(map($fx.rand(), 0, 1, 12222, 1222111)); //finalSeed;//floor(random(random(1000000)));

    if (creativeMode == true) {
        randomSeed(seed);
    } else {
        randomSeed(finalSeed);
    }


    /////RESOLUTION
    //r1 = 10;

    ///START SYSTEM
    runners = [];

    ///PG1
    numSystems = floor(map($fx.rand(), 0, 1, 3, 5.99));

    //DEFINE PROPORTIONS
    let ww, hh;
    //if (innerWidth > innerHeight) {
        ww = 2560;
        hh = 2560 / (innerWidth / innerHeight);
    // } else {
    //     hh = 1440;
    //     ww = 1440 * (innerWidth / innerHeight);
    // }


    let pgX = int(ww / r1 + 1);
    let pgY = int(hh / r1 + 1);
    pg = createGraphics(pgX, pgY);
    pg.pixelDensity(1);
    pg.colorMode(HSB);


    ///PG2
    numSystems2 = floor(map($fx.rand(), 0, 1, 3, 6));


    canvas.imageSmoothingEnabled = false;
    p5.disableFriendlyErrors = true;
    noSmooth();



    let fIx = int(ww / r1 + 1);
    let fIy = int(hh / r1 + 1);

    //FINALIMAGE AND TEMP ARRAY OF PIXELS
    finalImage = createImage(fIx, fIy);

    tempPixels = [];
    tempPixels2 = [];
    pixelDensity(1);


    ////SEED FOR COLORS AND SYSTEMS
    ///PALETTES 
    palette1 = [];
    palette2 = [];
    


    for (let i = 0; i < numSystems; i++) {
        colorPicker = floor(map($fx.rand(), 0, 1, 0, palette[palettePicker].length));
        finalCol = color(palette[palettePicker][colorPicker]);

        palette1[i] = finalCol;
    }

    for (let i = 0; i < numSystems2; i++) {
        colorPicker = floor(map($fx.rand(), 0, 1, 0, palette[palettePicker].length));
        finalCol = color(palette[palettePicker][colorPicker]);

        palette2[i] = finalCol;
    }



    ////RANDOM NUM OF COLUMNS
    columnsRandom = floor(map($fx.rand(), 0, 1, 1, 5));
    minColumns = 2;//floor(random(1, 1));
    maxColumns = 2;//floor(random(1, 1));





    console.log('systems: ' + numSystems);
    console.log('seed: ' + seed);
}



/////COMMANDS

function keyTyped() {

    ////PAUSE
    if (key === 'p') {
        running = !running;
    } else if (key === 's') {
        saveCanvas(palette[palettePicker] + '_' + nf(seed, 10, 0) + '.png');
    } else if (key === '1') {
        r1=10;
        start(seeds[seedIndex][int(seedCount)]);
    } else if (key === '2') {
        r1=20;
        start(seeds[seedIndex][int(seedCount)]);
    } else if (key === '3') {
        r1=40;
        start(seeds[seedIndex][int(seedCount)]);
    }
}


function keyPressed() {
    if (keyCode == DOWN_ARROW) {
        if (seedCount < 9) {
            seedCount++;
        } else {
            seedCount = 0;
        }

        start(seeds[seedIndex][int(seedCount)]);
    } else if (keyCode == UP_ARROW) {
        if (seedCount > 0) {
            seedCount--;
        } else {
            seedCount = 9;
        }

        start(seeds[seedIndex][int(seedCount)]);
    }
}


// function pxRect(xx, yy, ww, hh, ccc){
    
//     // let xxx = constrain(xx, marginX+ww/2, finalImage.width-marginX);
//     // let yyy = constrain(yy, marginY+hh/2, finalImage.height-marginY);
    


//     let rr = red(ccc);
//     let gg = green(ccc);
//     let bb = blue(ccc);
    
    
//         ////TOP LINE
//         for(let x=xx-ww/2; x<x+ww/2; x++){
//                 let tempIndex = (x + yy-hh/2 * finalImage.width)*4;

//                 finalImage.pixels[tempIndex] = rr;
//                 finalImage.pixels[tempIndex+1] = gg;
//                 finalImage.pixels[tempIndex+2] = bb;
//                 finalImage.pixels[tempIndex+3] = 255;
//         }

//         // ////BOTTOM LINE
//         // for(let x=xx-ww/2; x<x+ww/2; x++){
//         //     let tempIndex = (x + yy+hh/2 * finalImage.width)*4;

//         //     finalImage.pixels[tempIndex] = rr;
//         //     finalImage.pixels[tempIndex+1] = gg;
//         //     finalImage.pixels[tempIndex+2] = bb;
//         //     finalImage.pixels[tempIndex+3] = 255;
//         //  }

//         //  ///LEFT LINE
//         //  for(let y=yy-hh/2; y<y+hh/2; y++){
//         //     let tempIndex = (x-ww/2 + yy * finalImage.width)*4;

//         //     finalImage.pixels[tempIndex] = rr;
//         //     finalImage.pixels[tempIndex+1] = gg;
//         //     finalImage.pixels[tempIndex+2] = bb;
//         //     finalImage.pixels[tempIndex+3] = 255;
//         // }

//         // ///LEFT LINE
//         //  for(let y=yy-hh/2; y<y+hh/2; y++){
//         //     let tempIndex = (x+ww/2 + yy * finalImage.width)*4;

//         //     finalImage.pixels[tempIndex] = rr;
//         //     finalImage.pixels[tempIndex+1] = gg;
//         //     finalImage.pixels[tempIndex+2] = bb;
//         //     finalImage.pixels[tempIndex+3] = 255;
//         // }

// }




function pxRect(xx, yy, ww, hh, ccc){
    
    let xxx = xx;//constrain(xx, marginX+ww/2, finalImage.width-marginX);
    let yyy = yy;//constrain(yy, marginY+hh/2, finalImage.height-marginY);
    
    let aX = int(xxx-ww/2);
    let zX = int(xxx+ww/2);
    let aY = int(yyy-hh/2);
    let zY = int(yyy+hh/2);

    let rr = red(ccc);
    let gg = green(ccc);
    let bb = blue(ccc);
    
    if(aX > 0 && zX < finalImage.width && aY >0 && aY<finalImage.height){
        for(let x=aX; x<zX; x++){
                let tempIndex = (x + aY * finalImage.width)*4;

                finalImage.pixels[tempIndex] = rr;
                finalImage.pixels[tempIndex+1] = gg;
                finalImage.pixels[tempIndex+2] = bb;
                finalImage.pixels[tempIndex+3] = 255;
        }

        for(let x=aX; x<zX; x++){
            let tempIndex = (x + zY * finalImage.width)*4;

            finalImage.pixels[tempIndex] = rr;
            finalImage.pixels[tempIndex+1] = gg;
            finalImage.pixels[tempIndex+2] = bb;
            finalImage.pixels[tempIndex+3] = 255;
        }

        for(let y=aY; y<zY; y++){
            let tempIndex = (aX + y * finalImage.width)*4;

            finalImage.pixels[tempIndex] = rr;
            finalImage.pixels[tempIndex+1] = gg;
            finalImage.pixels[tempIndex+2] = bb;
            finalImage.pixels[tempIndex+3] = 255;
        }

        for(let y=aY; y<zY+1; y++){
            let tempIndex = (zX + y * finalImage.width)*4;

            finalImage.pixels[tempIndex] = rr;
            finalImage.pixels[tempIndex+1] = gg;
            finalImage.pixels[tempIndex+2] = bb;
            finalImage.pixels[tempIndex+3] = 255;
        }
    }

}



// function playSound() {
//     // starting the oscillator ensures that audio is enabled.
//     triOsc.start();
//     env.play(triOsc);
//   }