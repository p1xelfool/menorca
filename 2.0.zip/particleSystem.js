/*
----------------------------------------------------------------

----------------------------------------------------------------
*/

let ParticleSystem = function(tempColumns, tempInitialVel, tempCor, tempIndex, tempPg, tempW, tempH, layer) {
    this.particles = [];

    this.loc = createVector(0.0, random(-3.0,-4.0));
    this.vel = createVector(0.0, 0.0);
    this.acc = createVector(0.0, 0.0);
    
    this.lifespan = 160.0;
    
    this.columns = tempColumns;
    this.initialVel = tempInitialVel;
    this.cor = tempCor;
    
    this.stepToMiss = 1;
    this.index = tempIndex;
    this.intervalCells = 1;
    
    this.finalPg = tempPg;
    this.w = tempW;
    this.h = tempH;

    this.layer = layer;
    
    this.iMultiplier = 1;
    

    //if(this.rr<8){this.velMultiplier = 1.0}else if(this.rr<9){this.velMultiplier = 0.99}else{this.velMultiplier = 1.2};
    this.velMultiplier = 1.0;

  //  if(tempIndex > 1){
        this.mod = mod;//floor(random(2, 4));
        this.modMult = modMult;//floor(random(1, 3)*2);
    // }else{
         this.mod = modArray[floor(random(0, modArray.length))];//floor(random(2, 4));
         this.modMult = modMultArray[floor(random(0, modMultArray.length))];//floor(random(1, 3)*2);
    // }


    ////Glitch speed
    this.GlSpeedX = random(0.1, 20);
    this.GlSpeedY = random(0.1, 3);

    ///WHERE TO STOP
    this.stopper = random(0, this.h-marginX);

    if(random(1)>0.4){
        this.hasGlitch = true;
    }else{
        this.hasGlitch = false;
    }
};


ParticleSystem.prototype.update = function() {
    this.lifespan -= 2.0;
    
    
    let len = this.particles.length;

    for (let i = len - 1; i >= 0; i--) {
        let particle = this.particles[i];
        particle.update();
        particle.display();

        if (particle.isDead()) {
            this.particles.splice(i, 1);
        }
        
    }
}

ParticleSystem.prototype.isDead = function () {
    if (this.lifespan <= 0.0) {
        return true;
    } else {
        return false;
    }
}


ParticleSystem.prototype.force = function () {
    this.cent = createVector(0, this.h);
    this.p = p5.Vector.sub(this.cent, this.loc);
    
    this.p.normalize();
    this.p.mult(this.initialVel);
    if((t==1) && this.lifespan > 0){
        this.applyForce(this.p);
    }
}

ParticleSystem.prototype.applyForce = function(f) {
    this.acc.add(f);
}




ParticleSystem.prototype.nu = function() {
    this.vel.add(this.acc);
    this.loc.add(this.vel);
    
    this.acc.mult(0);
    this.vel.limit(3);
    this.vel.mult(this.velMultiplier);
    

    if(this.index < 1){
        if(t%this.stepToMiss == 0 && this.loc.y<this.h){
            this.particles.push(new Particle(0, this.loc.y, this.columns, this.cor, this.index, this.intervalCells, this.finalPg, this.w, this.h, this.layer, this.iMultiplier, this.mod, this.modMult, this.GlSpeedX, this.GlSpeedY, this.hasGlitch));
        }
    }else{
        if(t%this.stepToMiss == 0 && this.loc.y<this.h-this.stopper){
            this.particles.push(new Particle(0, this.loc.y, this.columns, this.cor, this.index, this.intervalCells, this.finalPg, this.w, this.h, this.layer, this.iMultiplier, this.mod, this.modMult, this.GlSpeedX, this.GlSpeedY, this.hasGlitch));
        }
    }

    

    
}
